#include <avr/io.h>
#include "timer.h"

void timer_init() {
  // timer0: 8bit, 256 values.
  TCCR0B = 3; // timer 0, prescaler 64 (=250kHz resolution)
  TIMSK0 |= (1<<TOIE0); // enable timer 0 overflow interrupts.
}
