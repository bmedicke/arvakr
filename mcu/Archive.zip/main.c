/* vim: foldmethod=syntax foldnestmax=1 foldenable
   benjamin medicke */

#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

#include "timer.h"
#include "uart.h"

void send_instructions() {
  uart_sendstring("benbenben");
}


ISR(TIMER0_OVF_vect) {
  static uint16_t count = 0;
  TCNT0 = 6; // reload value. next interrupt after 250 ticks (1ms)
  count++;
  if (count == 500) {
    count = 0;
    PINB |= (1<<PB5);
  }
}

int main() {
  uart_init(BAUD);
  timer_init();
  TCNT0 = 6; // reload value.
  DDRB |= (1<<PB5);
  sei(); // enable all interrupts.

  for (;;) {

  }
}
